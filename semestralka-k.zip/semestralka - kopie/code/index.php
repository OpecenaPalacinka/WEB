<?php

require_once("settings.inc.php");

require_once("ApplicationStart.class.php");

$app = new ApplicationStart();
$app->appStart();

?>
