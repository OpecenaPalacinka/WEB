V adresáři "code" se nachází všechen výkonný kód webové aplikace a nachází se zde i vstupní bod (index.php).
Adresář database obsahuje skript pro vytvoření a naplnění databáze. 
Adresář image obsahuje obrázky použité v semestrální práci.

Semestrální práce
<jméno>